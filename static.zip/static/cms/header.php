<html>
    <head>
        <meta charset="UTF-8">
        <title>Content Management System</title>
        
            <!-- Bootstrap v3 CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
            <!-- Bootstrap v3 -->
    </head>

    <body>
