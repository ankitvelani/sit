# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
from flask import Flask , render_template , request ,jsonify
import pandas as pd
import spacy
from autocorrect import spell
import random
import re
import inflect
inflect = inflect.engine()
import numpy as np




nlp = spacy.load('en_core_web_sm')

app = Flask(__name__)


DATA_FILE="./Data.xlsx"

data=pd.read_excel(DATA_FILE,sheet_name="By Queries")
data_by_tab=pd.read_excel(DATA_FILE,sheet_name="By Tab")



GREETING_INPUTS = ("hello", "hi", "greetings", "sup", "what's up","hey",)
GREETING_RESPONSES = ["Hi", "Hey I'm Robo", "Hi", "Hello", "I am glad! You are talking to me"]


# Checking for greetings
def greeting(sentence):
    """If user's input is a greeting, return a greeting response"""
    for word in sentence.split():
        if word.lower() in GREETING_INPUTS:
            return random.choice(GREETING_RESPONSES)

def clean_text(text):
    text = text.lower()
    text = re.sub(r"i'm", "i am", text)
    text = re.sub(r"i'm", "i am", text)
    text = re.sub(r"he's", "he is", text)
    text = re.sub(r"she's", "she is", text)
    text = re.sub(r"that's", "that is", text)
    text = re.sub(r"what's", "what is", text)
    text = re.sub(r"where's", "where is", text)
    text = re.sub(r"\'ll", " will", text)
    text = re.sub(r"\'ve", " have", text)
    text = re.sub(r"\'re", " are", text)
    text = re.sub(r"\'d", " would", text)
    text = re.sub(r"won't", "will not", text)
    text = re.sub(r"can't", "cannot", text)
    text = re.sub(r"[-()\"#/@;:<>{}+=~|.?,`]", "", text)
    text=text.replace(r"'","").replace(r'"', '')
    
    return text

def get_singular_form(doc):
    temp_word=""
    doc=clean_text(doc)
    for token in nlp(doc):
            if(inflect.singular_noun(token.text)):
                temp_word+=" "+inflect.singular_noun(token.text)
            else:
                temp_word+=" "+str(token.text)
    return (str.strip(temp_word))

def get_similarity(INPUT,DATA):
    
    similarity=[ nlp(str.strip(clean_text(str(title)))).similarity(nlp(INPUT.lower()))  for title in DATA['Title'] ]
    temp_df=pd.DataFrame(DATA)
    temp_df['similarity']=similarity
    temp_df=temp_df.sort_values(by='similarity',ascending=False).reset_index()

    del temp_df['index']
    index=[ index for index,similarity in enumerate(temp_df['similarity']) if similarity >= 0.90 ]
    
    if not len(index):
        index=[ index for index,similarity in enumerate(temp_df['similarity']) if similarity >= 0.68  ]
    if not len(index):
        index=[ index for index,similarity in enumerate(temp_df['similarity']) if similarity >= 0.55 ]
    if not len(index):
        index=[ index for index,similarity in enumerate(temp_df['similarity']) if similarity >= 0.40 ]    
    
    
    print(temp_df.iloc[index,[0,1,2]])
    return temp_df.iloc[index,[0,1,2]]


@app.route('/test')
def test1():
    tempData={}
    tempData['Category']=(data['Category'].unique())
    return render_template('test.html',result=tempData)


@app.route('/')
def index():
    tempData={}
    tempData['Category']=(data['Category'].unique())
    
    return render_template('index.html',result=tempData)


@app.route('/getCategoryLink',methods=['POST','GET'])
def getCategoryLink():
    
    user_input = request.form['user_query']
    
    index=[ index for index,Category in enumerate(data['Category']) if Category==user_input]
    res=""
    tempDF = data.iloc[index,[0,1]]
    res=[ "<ul> <li><a class='a-text btn-link'  onclick=\"getByTab('"+user_input+"')\">By Topics</a></li><li><a class='a-text btn-link'  onclick=\"getByQuestions('"+user_input+"')\">By Guided path</a></li></ul>"] 

    response={
        "Title":res,
        "CountOf":str(2)
        }
     
    return jsonify(response)


@app.route('/getQuestions',methods=['POST','GET'])
def getQuestions():
      
    user_input = request.form['user_query']
    index=[ index for index,Category in enumerate(data['Category']) if Category==user_input]
   
    tempDF = data.iloc[index,[0,3]]

    reslen=0
    res="<ul>"
    for x in zip(tempDF['Title'],tempDF['Link']):
        if not pd.isnull(x[0]):
            reslen+=1
            res+="<li><a class='a-text btn-link'  onclick=\"getSubQuestions('"+clean_text(str(x[0]))+"')\">"+str(x[0])+"</a></li>"
    
    res+="</ul>"
    temp=res
    
    '''res=str(res) 
    res=res.replace(',','')
    res=res.replace('\"','')
    res=res.replace('[','')
    res=res.replace(']','')
    '''
   
    
    response={
        "Title":res,
       
         "CountOf":str(reslen)
        }
     
    return jsonify(response)


@app.route('/getSubQuestions',methods=['POST','GET'])
def getSubQuestions():
      
    user_input = request.form['user_query']
    index=[ index for index,Category in enumerate(data['TitleForMatch']) if clean_text(str(Category))==user_input]
   
    tempDF = data.iloc[index,[2,3,1]]

    res=[]
    res+=[ "<li><a class='a-text text-left' target='_new' href='"+str(x[1])+"'>"+str(x[0])+"</a></li>" for x in zip(tempDF['SubQuestions'],tempDF['Link']) if not pd.isnull(x[0])]
    temp=res
    
    res=str(res)
    res=res.replace(',','')
    res=res.replace('\"','')
    res=res.replace('[','')
    res=res.replace(']','')
    res='<ul>'+res+'</ul>'
    
    
    response={
        "Title":res,
        'CategoryName':np.unique(tempDF['TitleForMatch'])[0],
         "CountOf":str(len(temp))
        }
     
    return jsonify(response)



@app.route('/getTab',methods=['POST','GET'])
def getTab():
    
     
    user_input = request.form['user_query']
    index=[ index for index,Category in enumerate(data_by_tab['Category']) if Category==user_input]
   
    tempDF = data_by_tab.iloc[index,[0,1]]
    
    
    res=[ "<li><a class='a-text text-left' target='_new' href='"+str(x[1])+"'>"+str(x[0])+"</a></li>" for x in zip(tempDF['Title'],tempDF['Link']) if not pd.isnull(x[0])]
    temp=res
    
    res=str(res) 
    res=res.replace(',','')
    res=res.replace('\"','')
    res=res.replace('[','')
    res=res.replace(']','')
    res='<ul>'+res+'</ul>'
   
    
    response={
        "Title":res,
         "CountOf":str(len(temp))
        }
     
    return jsonify(response)

@app.route('/chat',methods=['POST','GET'])
def chat():
    user_input = request.form['user_query']
    user_input=str.strip(user_input)
    
    temp_input=""
    similarity=pd.DataFrame()
    res=""
    response={
        'Title':"<a href='#' class='a-text'>I'm So Sorry !!!</a>",
        'ShortMsg':"I'm So Sorry !!!"
        }

    if(greeting(user_input)!=None):
        res='GREETING'
        greeting_res=greeting(user_input)
        response={
            'Title':"<a class='a-text'>"+greeting_res+"</a>",
            'ShortMsg':greeting_res,
            'CountOf':str(1)
        }
        return jsonify(response);
    if user_input.lower() in ['looks good','thanks a lot','thank','thank you','thank you so much','thanks robo','good bye','bye bye','thank you robo','thanks a lot','bye','see you','thanks']:
        res='GREETING'
        greeting_res=random.choice(["Welcome","I'm glad","Bye Bye..Take care",'Thank you','Thank you..Bye']);
        response={
             
            'Title':"<a class='a-text'>"+greeting_res+"</a>",
            'ShortMsg':greeting_res,
            'CountOf':str(1)
        } 
    else:
        doc_input=nlp(get_singular_form(user_input))
        
        for token in doc_input:
            if not token.is_punct:
                temp_input+=spell(token.text)+' '
            else:
                temp_input+=token.text
        
        INPUT=str.strip(temp_input)
        
        #print(data_by_tab.iloc[:,[0,1]])
        t=data.iloc[:,[2,3]]
        p=data_by_tab.iloc[:,[0,1]]
        t.columns=['Title','Link']
        consolidated_data=p.append(t,ignore_index=True)
        
        similarity=get_similarity(INPUT,consolidated_data)
        res=[]
        if similarity.empty:
            res=["I'm So Sorry !!!"]
        else:
            res+=[ "<li><a class='a-text text-left' target='_new' href='"+str(x[1])+"'>"+str(x[0])+"</a></li>" for x in zip(similarity['Title'],similarity['Link'],similarity['similarity']) if not pd.isnull(x[0])]

        if len(res)==0:
            res=["I'm So Sorry !!!"]
        temp=res
        
        res=str(res) 
        res=res.replace(',','')
        res=res.replace('\"','')
        res=res.replace('[','')
        res=res.replace(']','')   
        res='<ul>'+res+'</ul>'
    if res=='GREETING':
        pass;
    elif len(res):
        response={
            'Title':res,
            'ShortMsg':"I'm So Sorry !!!" if len(res) <= 16 else res,
            'CountOf':str(len(res))
        }
    
    return jsonify(response);
    

@app.route('/process',methods = ['POST', 'GET'])
def process():
    if request.method=="POST":
        data={}
        d=pd.DataFrame(columns=['Title', 'Score'])
        result = request.form
        query=result['comment']
        data['query']=query
        q_doc = nlp(query.lower())
        similarity=[[]]
        
        i=0
        for title in df.Title:
            doc=nlp(str(title).lower())
            
            similarity.append([title,doc.similarity(q_doc),df.iloc[i,1]])
            i=i+1
         
        result=pd.DataFrame(similarity,columns=['Title','Score','Link'])
        result=result.sort_values(by=['Score'],ascending=False).reset_index()
        data['link']=result.iloc[0,3]
        data['title']=result.iloc[0,1]
        
        return render_template('index.html',result = data)

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=80,debug=True) 
