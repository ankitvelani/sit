<?php
include './header.php';
include './navbar.php';
?>

<--- Body --->
<?php
include './footer.php';
?>