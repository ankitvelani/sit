

        <?php
            echo "Hello World!";


            print("This message from PHP");
        ?>