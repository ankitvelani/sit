<html>
    <head>
        <title>Form Element</title>
    </head>
    <body>
        <form>

            <lable>
                First Name:
            </lable>
            <input type='text' placeholder='enter your first name'>
            
            <br><br>

            <lable>
                Last Name:
            </lable>
            <input type='text' placeholder='ente your last name'>
            <br><br>
           
            <label>
                Entrance exam:
            </label>    
            <br>
            <input type='radio' value='PGCET' name='entrance'>
            <lable>PGCET</lable>
            
            <input type='radio' value='KMAT' name='entrance'>
            <lable>KMAT</lable>

            <br><br>
            <lable>
                Programming Language (multi select)
            </lable>
            <br>
            <input type='checkbox' value='C' name='programming'>
            <lable>C</lable>

            <input type='checkbox' value='C++' name='programming'>
            <lablel>C++</lablel>

            <input type='checkbox' value='PHP' name='programming'>
            <label>PHP</label>

            <input type='checkbox' value='Java' name='programming'>
            <lable>Java</lable>

            <input type='checkbox' value='Shell Script' name='programming'>
            <label>Shell Script</label>

            <br><br>
            <input type='submit'>
            <input type='reset'>
        </form>
    </body>
</html>