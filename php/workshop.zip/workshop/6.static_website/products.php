<html>
    <head>
        <title>Page | Products</title>
    </head>
    <body>

    <table>
        <tr>
            <th>
                <A href="home.php">Home</A>
            </th>
            <th>
                <A href="about.php">About</A>
            </th>
            <th>
                <A href="services.php">Services</A>
            </th>
            <th>
                <A href="products.php">Products</A>
            </th>
            <th>
                <A href="contact.php">Contact</A>
            </th>
        </tr>
    </table>
    
        <p>
            This is Products page.
        </p>
    </body>
</html>