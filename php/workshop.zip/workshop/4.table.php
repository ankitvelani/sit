<html>
    <head>
        <title>HTML Table</title>
    </head>
    <body>
        <table border='1'>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Marks</th>
            </tr>
            <tr>
                <td>John</td>
                <td>Nick</td>
                <td>60</td>
            </tr>
            <tr>
                <td>Dom</td>
                <td>Dominic</td>
                <td>80</td>
            </tr>
        </table>
    </body>
</html>