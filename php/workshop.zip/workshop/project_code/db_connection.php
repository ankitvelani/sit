
    <?php
        
        function connection(){

            $server= "localhost";
            $user= "root";
            $password= "";
            $db_name="student";
            
            $connection = new mysqli($server,$user,$password, $db_name);

            return $connection;
        }

        function insert($conn, $qry){

            $response = $conn->query($qry);
            print_r($response);
            if ($response) {
                echo "New record created successfully";
            } else {
                echo "Insertion Failed!!";
            }

        }
        function select($conn, $qry){

            $response = $conn->query($qry);
            $result = mysqli_fetch_all($response);
            
            return $result;
        }
        
        function delete($conn, $qry){

            $response = $conn->query($qry);
            
            return $response;
        }