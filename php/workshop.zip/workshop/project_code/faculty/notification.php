
<?php


require "../db_connection.php";
$conn = connection();

$qry = "SELECT * FROM notification";
$res = select($conn, $qry);




?>

<html>
    <header>
        <title>
            Notification | Factuly
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Notification
            </h1>
            <a href="add_notification.php">Add Nofitication</a> <a href="home.php">Home</a> <a href="view_students.php">View Students</a>
            

            <?php 
            
            foreach($res as $notification){
                echo "<p>$notification[1]";
                echo "    <a href='delete_notification.php?id=$notification[0]'>Delete</a></p>";
            }
            
            ?>
               
                
        </pre>
    </body>
</html>
