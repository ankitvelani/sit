<html>
    <header>
        <title>
            Home Page | Faculty
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Hi Faculty !, Welcome to Student Portal
            </h1>
            <a href="notification.php">Notification</a>
            <a href="view_students.php">View Students</a>

        </pre>
    </body>
</html>

<?php


