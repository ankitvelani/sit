<html>
    <header>
        <title>
            Login Page | Faculty
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
                Login Page
            </h1>
            <form>
                    Email       : <input type='email' name='email' required>
                    <br>
                    Password    : <input type='password' name='password' required>
                    <br>

                    <input type='submit' value='Login' name='login'> <input type='reset' value='Reset' name='reset'>
            </form>
        </pre>
    </body>
</html>

<?php


