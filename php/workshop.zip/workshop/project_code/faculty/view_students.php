
<?php


require "../db_connection.php";
$conn = connection();

$qry = "SELECT * FROM students";
$res = select($conn, $qry);




?>

<html>
    <header>
        <title>
            Student list | Factuly
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
            Students list
            </h1>
            <a href="home.php">Home</a> <a href="notification.php">Notification</a>
            <table>
                <tr>
                    <th>Sr.</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                </tr>

                <?php

                 
                foreach($res as $student){
                    echo "<tr>
                            <td>$student[0]</td>
                            <td>$student[1]</td>
                            <td>$student[2]</td>
                            <td>$student[3]</td>
                        </tr>";
                }
                ?>
                
            </table>
        </pre>
    </body>
</html>

<?php


