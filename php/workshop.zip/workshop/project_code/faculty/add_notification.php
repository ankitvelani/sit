<html>
    <header>
        <title>
            Notification | Factuly
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Notification
            </h1>
            <a href="notification.php">View Nofitication</a> <a href="home.php">Home</a> <a href="view_students.php">View Students</a>
            
            <form>
                <b>Message :</b>

                <textarea rows="8" cols="80" name="notificaiton">
                    type....message/new/notification to display at Students page
                </textarea>

                                                                                       <input type="submit" name="add" value="Add">  <input type="reset" name="reset" value="Clear">
                
            </form>


        </pre>
    </body>
</html>

<?php


require "../db_connection.php";
$conn = connection();



$notificaiton = $_GET['notificaiton'];

if ($notificaiton){
    
    $qry = "INSERT INTO notification VALUES (NULL,'$notificaiton')";
    $conn  = connection();
    insert($conn, $qry);

}