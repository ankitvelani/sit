<?php
require "../db_connection.php";
$conn = connection();

$id = $_GET['id'];
$qry = "DELETE FROM notification where id =$id";

$response = delete($conn,$qry);


if($response)
    header("Location: ./notification.php?");