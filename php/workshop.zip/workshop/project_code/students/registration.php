<html>
    <header>
        <title>
            Registration Page | Student
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
                Registration
</h1>
            
            <form>
                    First Name  : <input type='text' name='firstname' required>
                    <br>
                    Last Name   : <input type='text' name='lastname' required>
                    <br>
                    Email       : <input type='email' name='email' required>
                    <br>
                    Password    : <input type='password' name='password' required>
                    <br>

                    <input type='submit' value='Register' name='register'> <input type='reset' value='Cancel' name='cancel'>
            </form>
        </pre>
    </body>
</html>

<?php


require "../db_connection.php";
$conn = connection();



$first_name = $_GET['firstname'];
$last_name = $_GET['lastname'];
$email = $_GET['email'];
$password = $_GET['password'];

$qry = "INSERT INTO students  VALUES (NULL,'$first_name', '$last_name','$email','$password')";
$conn  = connection();
insert($conn, $qry);
