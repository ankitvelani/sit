<?php

$student_name = $_GET['student'];



require "../db_connection.php";
$conn = connection();

$qry = "SELECT * FROM notification";
$res = select($conn, $qry);



?>

<html>
    <header>
        <title>
            Home Page | Student
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Hi <?php echo $student_name; ?>!!, Welcome to Student Portal
            </h1>
            <p>
            <h2>Notifications</h2>
            <?php 
            
            foreach($res as $notification){
                echo "<p>$notification[1]</p>";
               
            }
            
            ?>
               
            
            </p>

        </pre>
    </body>
</html>

<?php


