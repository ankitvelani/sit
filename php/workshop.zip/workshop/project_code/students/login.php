<html>
    <header>
        <title>
            Login Page | Student
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
                Login Page
            </h1>
            <form>
                    Email       : <input type='email' name='email' required>
                    <br>
                    Password    : <input type='password' name='password' required>
                    <br>

                    <input type='submit' value='Login' name='login'> <input type='reset' value='Reset' name='reset'>
            </form>
        </pre>
    </body>
</html>

<?php

require "../db_connection.php";
$conn = connection();

$email = $_GET['email'];
$password = $_GET['password'];

$qry = "SELECT * FROM students where email='$email' AND password ='$password'";
$res = select($conn, $qry);


if (count($res) == 1){
        $student_name ="";  
        $student_id =""; 
        foreach($res as $row){
            print($row[0]);
            print($row[1]);
            $student_id = $row[0];
            $student_name = $row[1];
        }

        header("Location: ./home.php?student=$student_name");

}else{
    echo "Login Failed !!";
}


