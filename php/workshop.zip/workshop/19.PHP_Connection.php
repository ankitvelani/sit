<?php

$host = "localhost";
$user = "root";
$pass = "";

$connection = mysqli_connect($host,$user,$pass);

print_r($connection);