<?php

echo "<h4> Array </h4>";

$subjects = array("C","C++","Java","C#","PHP");

print_r($subjects);

echo "<br>";

$name[0] ="AAA";
$name[1] ="BBB";
$name[2] ="CCC";

print_r($name);

echo "<br><br>";
// Associative Array
$students = array(
    "USN01" => "John",
    "USN02" => "Nick",
    "USN03" => "Kevin"    );

print_r($students);


# Multi Dimensional Array

$students = array(
    array("USN01",'John',23),
    array("USN02",'Nick',17),
    array("USN03",'Kevin',19)
    
);

for($i=0;$i<3;$i++)
    for($j=0; $j<3; $j++)
        echo "<br><br>".$students[$i][$j];
