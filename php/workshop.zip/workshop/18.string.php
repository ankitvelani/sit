<?php

$name = "John";
echo 'Hi $name, welcome to PHP';
echo "<br><br>";
echo "Hi $name, welcome to PHP";

