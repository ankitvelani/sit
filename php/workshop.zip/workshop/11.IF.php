<html>
    <body>
        <form method='GET' action="11.IF.php">
            Number : <input type='number' name='number'>

            <br>
            <input type='submit'>
        </form>
    </body>
</html>

<?php


    $num = $_GET['number'];

    if($num < 10){
        echo " $num is less than 10.";
    }

    echo "<br><br>";
    if($num %2 == 0){
        echo "$num is even number";
    }
    else{
        echo "$num is odd number";
    }