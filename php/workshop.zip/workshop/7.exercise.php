<html>
<head>
  <title>Form Tag Example</title>
</head>
<body>

<h4> Registration Form</h4>
<form>

    <label>First Name</label> 
    <input type="text">
    <br><br>

   <label>Last Name:</label>
   <input type="text">
   <br><br>

   <label>Password:</label>
   <input type="password">
   <br><br>
   
   Gender:
   <input type="radio" name="gender"><label>Male</label>
   <input type="radio" name="gender"><label>Female</label>
   <br><br>
   
   Id Proof:
   <input type="checkbox" name="ids"> <label>Aadhar Card</label>
   <input type="checkbox" name="ids"> <label>Driving Card</label>
   <input type="checkbox" name="ids"> <label>PAN Card</label>
   <br><br>
   
   State: <select>
           <option>Karnataka</option>
           <option>Maharastra</option>
           <option>Gujarat</option>
           <option>UP</option>
           <option>Bihar</option>
           <option>Rajasthan</option>
         </select>
        <br><br>
   
   Comment: <textarea></textarea>
   <br><br>

   <input type="submit" value="Submit" /> <input type="reset" />
 </form>
</body>
</html>