<?php

    $str = "Hello world from PHP";

    $STR = "This is string";

    echo $str;
    echo $STR;

    $x = 10;
    $y = 55.55;

    echo "<br>";
    echo $x;
    echo "<Br>";
    echo $y;

    echo "<br><br>";
    echo gettype($x);
    echo "<Br>";
    echo gettype($STR);

    echo "<br>";
    echo gettype($y);
    

?>