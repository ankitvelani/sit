<html>
    <head>
        <title>Form with PHP</title>
    </head>
    <body>
        <form method="POST"  action="10.php_action.php">
            <br><br>
            First Name  <input type='text' name='first_name'>
            <br><br>
            Last  Name  <input type='text' name='last_name'>
            <br><br>

            <input type='submit'>
 
        </form>
    </body>

</html>