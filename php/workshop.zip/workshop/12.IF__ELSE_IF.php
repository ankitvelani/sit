<?php

    $marks = 68;

    if($marks < 34)
        echo "Sorry ! you have not score minimum marks";
    elseif($marks >=35 && $marks <=50)
        echo "D-Grade";
    elseif($marks >50 && $marks <=65)
        echo "C-Grade";
    elseif($marks >65 && $marks <=80)
        echo "B-Grade";
    elseif($marks >80 && $marks <=90)
        echo "A-Grade";
    elseif($marks >90 && $marks <=100)
        echo "A+ Grade";
    else
        echo "Invalid Input";