<html>
    <header>
        <title>
            Student list | Factuly
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
            Students list
            </h1>
            <a href="home.php">Home</a> <a href="notification.php">Notification</a>
            <table>
                <tr>
                    <th>Sr.</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td>John</td>
                    <td>Nick</td>
                    <td>John.Nick@gmail.com</td>
                </tr>
            </table>
        </pre>
    </body>
</html>

<?php


