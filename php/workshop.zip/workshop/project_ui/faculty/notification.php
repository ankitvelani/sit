<html>
    <header>
        <title>
            Notification | Factuly
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Notification
            </h1>
            <a href="add_notification.php">Add Nofitication</a> <a href="home.php">Home</a> <a href="view_students.php">View Students</a>
            
                <p>
                Notificaiton will get display here
                
                <a href='#'>Delete</a>
                </p>
                
        </pre>
    </body>
</html>

<?php


