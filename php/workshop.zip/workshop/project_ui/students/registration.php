<html>
    <header>
        <title>
            Login Page | Student
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
                Registration
</h1>
            
            <form>
                    First Name  : <input type='text' name='firstname' required>
                    <br>
                    Last Name   : <input type='text' name='lastname' required>
                    <br>
                    Email       : <input type='email' name='email' required>
                    <br>
                    Password    : <input type='password' name='password' required>
                    <br>

                    <input type='submit' value='Register' name='register'> <input type='reset' value='Cancel' name='cancel'>
            </form>
        </pre>
    </body>
</html>


