<html>
    <header>
        <title>
            Home Page | Student
        </title>
    </header>
    <body>
        
        <pre>
            <h1>
               Hi User !, Welcome to Student Portal
            </h1>
            <p>
               
                  Notice/News will display here...
            
            </p>

        </pre>
    </body>
</html>

<?php


