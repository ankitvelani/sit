<?php


// This is single line comments

/*
This is multi-line comment in PHP and 
this will not get executed 
by PHP interpreter
*/

# This comment is UNIX style comment

echo "Hello World!";