<?php

echo "Hello This Message from Action File<br><br>";

echo "First Name : ";
echo $_POST['first_name'];

echo "<br>";
print_r($_REQUEST);