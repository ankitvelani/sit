<html>
    <head>
        <title>PHP & MySQL Insert </title>
    </head>
    <body>

        <form method="get">
            Name : <input type="text" name="student_name">
            <br>
            <br>
            Email : <input type="email" name="student_email">
            <br><br>
            <input type="submit" name="submit" value="Insert">
        </form>
        
        
    </body>
</html>
<?php
    // Establish connection with MySQL
    function connection(){

        $server= "localhost";
        $user= "root";
        $password= "";
        $db_name="student";
        
        $connection = new mysqli($server,$user,$password, $db_name);

        return $connection;
    }

    function insert($conn, $qry){

        $response = $conn->query($qry);
        print_r($response);
        if ($response) {
            echo "New record created successfully";
        } else {
            echo "Insertion Failed!!";
        }

    }



    $name = $_GET['student_name'];
    $email = $_GET['student_email'];

    $qry = "INSERT INTO test VALUES (NULL,'$name', '$email')";
    $conn  = connection();
    insert($conn, $qry);

?>