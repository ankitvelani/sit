<?php
    include "header.php";
?>
    
        <p>
            This is Contact us page.
        </p>

<?php
    include "footer.php";
?>