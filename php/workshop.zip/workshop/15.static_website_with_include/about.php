<?php
    include "header.php";
?>
        <p>
            This is About page
        </p>
<?php
    include "footer.php";
?>