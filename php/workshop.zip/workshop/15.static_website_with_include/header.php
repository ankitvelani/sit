<?php
$file_name = $_SERVER['SCRIPT_NAME'];

$name_split = explode('/',$file_name);
$php_file_name = $name_split[3];

$php_file_name_only = explode(".", $php_file_name)[0];


?>

<html>
    <head>
        <title>Page | <?php echo $php_file_name_only; ?></title>
    </head>
    <body>

    <table>
        <tr>
            <th>
                <A href="home.php">Home</A>
            </th>
            <th>
                <A href="about.php">About</A>
            </th>
            <th>
                <A href="services.php">Services</A>
            </th>
            <th>
                <A href="products.php">Products</A>
            </th>
            <th>
                <A href="contact.php">Contact</A>
            </th>
        </tr>
    </table>
