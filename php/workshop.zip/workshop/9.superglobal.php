<?php

$x = 10;

print_r($_SERVER);

echo "<br><br>";
echo $_SERVER['SERVER_SOFTWARE'];

echo "<br>";
echo $GLOBALS['x'];
echo "<br>";

function test(){
 
    $x = 9999;
    echo $x;

    echo "<br><br>";
    echo $GLOBALS['x'];
}

test();