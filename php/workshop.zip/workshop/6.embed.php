<html>
    <head>
        <title>
            Embed PHP code with HTML
        </title>
    </head>
    <body>

        <?php
            echo "Hi, This is PHP String";


            print("<br><br> <hr>This PHP <u>String has</u> HTML tag <b>inside</b>.");
        ?>

    </body>
</html>