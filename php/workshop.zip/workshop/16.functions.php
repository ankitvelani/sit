<?php

// simple function
function display(){
    echo "Hi !!";
}

// Function call
display();

echo "<br>";

// parameteries function
function display_p($name){
    echo "Hi $name !!";
}
display_p("John");

echo "<br><br>";

// default argment 
function display_d($name="User"){
    echo "Hi $name !!";
}
display_d("Nick");

echo "<br><br>";
// Call by reference
function display_r(&$name){
    $name = "Modifed..$name";
}

$name = "John";
echo "<br>Name Before Function Call : $name";
display_r($name);
echo "<br>Name After Function Call  :  $name";



// Variable length arguments
function display_v(...$name_list){
    echo "<br><br> Hi from variable length arg function: ";
    foreach($name_list as $name){
        echo "<br>$name";
    }
}

display_v("John", "Nick", "Kevin");