<html>
    <head>
        <title>PHP & MySQL Insert </title>
    </head>
    <body>

 
        
        
    </body>
</html>
<?php
    // Establish connection with MySQL
    function connection(){

        $server= "localhost";
        $user= "root";
        $password= "";
        $db_name="student";
        
        $connection = mysqli_connect($server,$user,$password, $db_name);

        return $connection;
    }

    function select($conn, $qry){

        $response = $conn->query($qry);
        $result = mysqli_fetch_all($response);
        
        return $result;
    }

    $conn = connection();
    $res = select($conn, "SELECT * FROM test");

    
    foreach($res as $row){
        print($row[0]);
        print($row[1]);
        print($row[2]);

        echo "<br>";
    }
?>