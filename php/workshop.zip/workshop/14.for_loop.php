<?php


$n = 10;
for($i=0; $i<$n; $i++){
    echo $i;
    echo "<br>";
}


$n = 10;
$i = 0;
while($i < $n){
    echo "Print Number $i from While Loop";
    echo "<br>";
    $i++;
}

echo "<br><br>";

$n = 10;
$i = 0;
do{

    echo "Print Number $i from Do..While Loop";
    echo "<br>";
    $i++;

}while($i < $n);

echo "<br><br>";
//Foreach loop
$subjects = array("C","C++","PHP","JAVA","DBMS");
foreach($subjects as $sub){
    echo ($sub);
    echo "<br>";
}